package hr.fer.infsus.sausc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SauscApplication {

    public static void main(String[] args) {
        SpringApplication.run(SauscApplication.class, args);
    }

}
